<?php
$conn = mysqli_connect('localhost:3306', 'uni', 'phpmysql', 'sms') or die('NO ANSWER FROM THE BACK.');
