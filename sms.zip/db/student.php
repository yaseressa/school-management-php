<?php 
class Student {
    $grade;
    $section;
    function applyLeave(date);
    function checkMarks();
    function payFees(amount);
    function checkAttendance();
    function checkTimeTable();
    function raiseIssue();
  }

?>