<?php 
            $conn = mysqli_connect('localhost:3333','uni', 'phpmysql', 'sms') or die('NO ANSWER FROM THE BACK.');

?>