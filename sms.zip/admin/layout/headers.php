<div class="z-20 w-[100%] fixed h-[70px] bg-slate-100 bg-opacity-50 text-slate-600 m-auto">
   <div class=" pt-3 mx-16 ml-10 flex justify-between items-center">
      <div class="flex justify-evenly bg-slate-600 items-center p-3 h-10 rounded-2xl">
         <img src="../resource/admin-av.png" width="50" alt="" class=" bg-slate-500 p-2 rounded-full">
         <h1 class="   text-slate-200 m-4 uppercase">Admin</h1>
      </div>
      <h1 class="text-3xl">School Management System</h1>
      <a href="logout.php" class="flex flex-row justify-start items-center"> <i class=" text-slate-900 fa-shake fa fa-lg  fa-sign-out side_bar_icon"></i></a>
   </div>
</div>